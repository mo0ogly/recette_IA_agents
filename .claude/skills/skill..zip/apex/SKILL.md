---
name: apex
description: Methodologie structuree APEX (Analyze-Plan-Execute-eXamine) pour implementer des features de facon systematique avec 10 etapes autonomes, validation, review adversariale, tests, et creation de PR. Utiliser quand une tache necessite plus de 2 etapes, touche plusieurs fichiers, ou presente des risques. Se declenche sur "apex", "plan d'attaque", "implemente cette feature", "workflow structure".
---

# APEX - Analyze, Plan, Execute, eXamine

Pipeline systematique en 10 etapes pour toute tache non-triviale dans LIA-SEC.
Inspire de Codelynx APEX, Explore-Plan-Execute (Upsun), Everything-Claude-Code, et Trail of Bits.

## Syntaxe

```
/apex [flags] <description de la tache>
```

## Flags

| Flag | Description |
|------|-------------|
| `-a` / `--auto` | Skip confirmations, auto-approve plans |
| `-x` / `--examine` | Active la review adversariale (etape 05) |
| `-s` / `--save` | Sauvegarde chaque etape dans `.claude/output/apex/` |
| `-t` / `--test` | Inclut creation + execution de tests (etapes 07-08) |
| `-b` / `--branch` | Verifie qu'on n'est pas sur main, cree une branche si besoin |
| `-pr` / `--pull-request` | Cree une PR a la fin (active -b automatiquement) |
| `-e` / `--economy` | Pas de subagents, economise les tokens |
| `-r <id>` / `--resume <id>` | Reprend depuis une tache precedente |

**Par defaut (sans flags) :** confirmation a chaque etape, pas de tests, pas de PR.

## Les 10 etapes

### ETAPE 00 : INIT
- Parser les flags et la description
- Creer le dossier output si `-s` (`_alire/temp/apex/{task-id}/`)
- Verifier l'etat git (branche, uncommitted changes)
- Si `-b` : verifier qu'on n'est pas sur main/master, creer branche `feat/{task-slug}`

### ETAPE 00b : PRE-FLIGHT CHECK (BLOQUANT)

Avant toute analyse, verifier que l'environnement est operationnel :

```bash
# Backend
curl -s -o /dev/null -w "%{http_code}" http://localhost:8081/api/health
# -> 200 = OK | autre = STOP, fixer d'abord

# PostgreSQL
psql -U lia_admin -d lia_scan -c "SELECT 1" 2>/dev/null
# -> OK | FAIL = STOP, auth/service a fixer

# Frontend build (si tache frontend)
cd sigma-react-frontend && node node_modules/.bin/vite build 2>&1 | tail -1
# -> "built in" = OK | erreurs = STOP, fixer d'abord

# Go build (si tache backend)
bash cmd/sigma_web/build_secure_lia.sh 2>&1 | grep "Build réussi"
# -> OK | FAIL = STOP, fixer d'abord
```

**Si un pre-flight echoue :**
1. Informer l'utilisateur du blocage
2. Proposer de fixer le pre-requis d'abord
3. NE PAS continuer sur une base cassee (le smoke test final echouera de toute facon)

**Exception :** si la tache EST de fixer le pre-requis qui echoue, continuer.

### ETAPE 01 : ANALYZE (comprendre, pas coder)

Exploration pure du code existant. ZERO ligne de code produite.

1. **Lire les fichiers concernes** : Glob + Grep + Read
2. **Cartographier les dependances** : qui appelle quoi, imports, routes API
3. **Triage d'usage (OBLIGATOIRE pour fichiers existants)** :
   ```bash
   # Pour chaque symbole public du fichier (fonctions, types, constantes) :
   grep -rn "SymbolName" *.go | grep -v le_fichier_lui_meme.go
   # 0 resultats = DEAD CODE -> proposer .disabled, NE PAS corriger
   # N resultats = ACTIF -> corriger/activer
   ```
   Classer chaque fichier : **ACTIF** (appele) / **DEAD** (0 appels) / **PROTOTYPE** (code propre, routes commentees)
   Presenter le triage a l'utilisateur AVANT d'investir du temps a corriger du dead code.
4. **Identifier les patterns existants** : conventions, nommage, architecture en place
5. **Consulter la documentation** : `_alire/01_DOCUMENTATION/`, CLAUDE.md, skills
6. **Verifier les contraintes LIA-SEC** : MUI v7, ConfigurationService, fetchWithConfig, logger custom, R1-R10

Output (si `-s`) : `01-analyze.md`
```
FICHIERS CONCERNES : [liste avec lignes]
DEPENDANCES : [qui appelle quoi]
PATTERNS EXISTANTS : [conventions detectees]
CONTRAINTES : [MUI v7, logger, fetchWithConfig, etc.]
RISQUES : [ce qui peut casser]
```

Gate : presenter l'analyse a l'utilisateur. Attendre validation sauf si `-a`.

### ETAPE 02 : PLAN (architecturer avant d'implementer)

Strategie fichier par fichier avec ordre d'implementation.

1. **Decomposer en etapes atomiques** : 1 etape = 1 fichier ou 1 fonction
2. **Ordonner par dependance** : ce qui doit exister avant le reste
3. **Identifier les gates entre etapes** : compilation, tests, validation
4. **Estimer le blast radius** : fichiers impactes, routes, composants
5. **Definir le rollback** : comment revenir en arriere

Format du plan :
```
ETAPE 1 : [action] -> [fichier:ligne] -> [gate: go build / npm run build / validate_rules_ALL.sh]
ETAPE 2 : [action] -> [fichier:ligne] -> [gate: ...]
...
ROLLBACK : git stash / git checkout -- [fichiers]
CRITERES DE SUCCES : [quand c'est "done"]
```

Technique avancee : demander a un subagent de critiquer le plan comme s'il etait ecrit par quelqu'un d'autre (pattern "adversarial review du plan").

Output (si `-s`) : `02-plan.md`

Gate : presenter le plan a l'utilisateur. Attendre validation sauf si `-a`.

### ETAPE 03 : EXECUTE (implementer avec discipline)

Implementation guidee par le plan. Chaque changement est tracke.

Regles :
1. **1 etape a la fois** : pas de multi-fichier sans validation
2. **Gate apres chaque etape** : compilation, lint, tests unitaires
3. **Pas de drift** : si un probleme emerge, revenir au PLAN, pas improviser. Si 2+ etapes echouent consecutivement, INVOQUER `/replan` (boucle OBSERVE -> COMPARE -> DECIDE -> AJUSTE) au lieu de replanifier implicitement. La replanification produit un nouveau `PLAN_*_REPLAN_*.md` dans `_alire/tracking/`.
4. **Logger les decisions** : ecrire dans `_alire/02_LOGS/Journals/decision_log.jsonl` pour chaque choix d'architecture ou replanification (format JSONL, voir `.claude/rules/agentic-traceability.md`)
5. **Conventions LIA-SEC strictes** :
   - Go : `logger.LogSystemEvent()`, pas `fmt.Println()`
   - React : `fetchWithConfig()`, pas `fetch()` brut
   - MUI v7 : `<Grid size={{ xs: 12 }}>`, pas `<Grid item xs={12}>`
   - ConfigurationService : `getBackendUrl()`, pas `http://localhost:8081`
   - Zero emoji, zero TODO, zero placeholder, zero mock
6. **Policy gates (BLOQUANT, verifier AVANT d'ecrire du code)** :
   - **NO STUB** : JAMAIS creer de fichiers `*_stubs.go` ou handlers retournant 501/placeholder. Si une dependance manque, l'implementer reellement ou informer l'utilisateur.
   - **NO MOCK** : JAMAIS de donnees fictives, hardcodees ou inventees
   - **USAGE** : chaque fonction/type cree DOIT etre appele quelque part. Si on renomme une fonction, verifier que le nouveau nom est utilise -- sinon c'est du dead code deplace.
   - **NO DISABLE** : JAMAIS ajouter `//go:build ignore`, renommer en `.disabled`, ou commenter tout un fichier sans accord explicite

Gates obligatoires selon le contexte :
| Contexte | Gate |
|----------|------|
| Go backend | `go build ./cmd/sigma_web/` + `go vet` |
| React frontend | `npm run build` (zero TS errors) |
| Regles LIA | `validate_rules_ALL.sh` (145 checks) |
| ReportRule JSON | `validate_reportrules.sh` (8 checks) |
| Moteur | `bin/lia_scan_engine -multi -rules . -events test_data.json` |

Output (si `-s`) : `03-execute.md`

### VERIFICATION GATE (BLOQUANT)

Apres chaque modification de code, AVANT de declarer "termine" :

1. **BUILD GATE** : `bash cmd/sigma_web/build_secure_lia.sh` (Go) + `cd sigma-react-frontend && node node_modules/.bin/vite build` (React)
2. **TEST GATE** : `cd sigma-react-frontend && npx vitest run` (tests existants ne cassent pas)
3. **IMPORT GATE** : Verifier imports manquants (alpha, useTheme, fetchWithConfig, customLogger)
4. **REGRESSION GATE** : Le code modifie ne doit pas introduire de nouveaux bugs
5. **SMOKE TEST** : Verifier que les endpoints/pages fonctionnent

Si une gate echoue : STOP, corriger, re-gate. JAMAIS declarer "termine" sans les 5 gates vertes.
Incident de reference : 188 fichiers casses par imports manquants (2026-03-17).

**Re-verification apres agents :** Si un subagent (cve-research-agent, recipe-tester-agent, etc.) modifie des fichiers pendant l'execution, re-executer les 5 gates AVANT de continuer. Les agents ne verifient pas les builds.

### ETAPE 04 : VALIDATE (auto-verification)

Verification automatique de la qualite :

1. **Diff complet** : `git diff` -- relire TOUT ce qui a change
2. **Anti-patterns LIA-SEC** :
   - R4 : pas de mock, placeholder, donnees fictives
   - R6 : logger custom uniquement (pas console.log, fmt.Println)
   - R10 : zero emoji
   - fetch() brut interdit (fetchWithConfig obligatoire)
   - localhost hardcode interdit (ConfigurationService)
3. **Compilation/build** : tout doit passer
4. **Securite OWASP** : SQL injection, XSS, command injection, path traversal

Output (si `-s`) : `04-validate.md`

### ETAPE 05 : EXAMINE (review adversariale, optionnelle avec `-x`)

Review critique comme si le code etait ecrit par quelqu'un d'autre :

1. **Analyse critique** : qu'est-ce qui pourrait mal tourner en production ?
2. **Review securite** : OWASP top 10, inputs non valides, injection
3. **Review performance** : N+1 queries, boucles couteuses, pagination manquante
4. **Review maintenabilite** : SRP, DRY, nommage, complexite
5. **Verdict** : PASS / ISSUES_FOUND (avec liste)

Si ISSUES_FOUND -> passer a l'etape 06 (Resolve).

Output (si `-s`) : `05-examine.md`

### ETAPE 06 : RESOLVE (corriger les issues, si etape 05 en a trouve)

1. Corriger chaque issue identifiee par l'Examine
2. Re-valider (retour a l'etape 04)
3. Documenter les corrections

Output (si `-s`) : `06-resolve.md`

### ETAPE 07 : TESTS (creation de tests, optionnelle avec `-t`)

1. **Analyser** les tests existants pour le code modifie
2. **Creer** les tests manquants :
   - Go : `*_test.go` dans le meme package
   - React : `*.test.tsx` a cote du composant
   - Regles : `test_data.json` (14+ cas, ratio 60/40 vuln/safe)
3. **Verifier** que les tests echouent AVANT l'implementation (TDD si applicable)

Output (si `-s`) : `07-tests.md`

### ETAPE 08 : RUN TESTS (execution, optionnelle avec `-t`)

1. Executer tous les tests concernes
2. Si echec : corriger et re-executer (boucle jusqu'a vert)
3. Verifier la couverture

Output (si `-s`) : `08-run-tests.md`

### ETAPE 09 : FINISH (finalisation)

1. **Tracking** : mettre a jour le plan persistant `_alire/tracking/PLAN_*.md` (Status: TERMINE, cocher les etapes, remplir le Resultat). Si pas de plan persistant, en creer un retroactivement avec le template `PLAN_TEMPLATE.md`.
2. **Evolutions** (Bloc 9 CLAUDE.md) :
   - Quick win (5 min)
   - Amelioration notable (30min-2h)
   - Refactor significatif (demi-journee+)
3. Si `-pr` : creer la Pull Request avec `gh pr create`
4. Si `-b` sans `-pr` : informer de la branche prete

Output (si `-s`) : `09-finish.md`

## Mode Resume

```
/apex -r <task-id>
```

1. Localiser le dossier dans `_alire/temp/apex/`
2. Lire `00-context.md` pour restaurer la tache, les flags, les criteres
3. Scanner les fichiers d'etapes existants pour determiner la derniere etape completee
4. Reprendre a l'etape suivante

## Mode Economy (`-e`)

Pas de subagents, tout se fait dans le contexte principal. Pour les plans limites en tokens.

## Mode Light (taches simples, 1-2 fichiers)

```
A: "Je modifie X dans Y, dependance Z"
P: "Etape 1: ..., Gate: compilation"
E: [code]
X: "Diff OK, anti-patterns OK, compile OK"
```

## Mode Batch (audit multi-fichiers)

Quand la tache concerne N fichiers a auditer/corriger (ex: "14 fichiers exclus du build") :

```
/apex --batch <description>
```

**Phase 1 : TRIAGE RAPIDE (5 sec/fichier)**

Pour chaque fichier, grep les symboles publics et compter les appels externes :
```bash
# Extraire fonctions/types publics du fichier
grep "^func \|^type " fichier.go | awk '{print $2}' | cut -d'(' -f1

# Pour chaque symbole, chercher les appels hors du fichier
grep -rn "SymbolName" *.go | grep -v fichier.go | wc -l
```

Classer chaque fichier :
| Categorie | Critere | Action |
|-----------|---------|--------|
| **ACTIF** | Symboles appeles ailleurs | Corriger/activer |
| **PROTOTYPE** | Code propre, routes commentees, 0 appels | Proposer activation ou disable |
| **DEAD** | 0 appels, code obsolete (ex: SQLite dans projet PostgreSQL) | Proposer .disabled |

Presenter le tableau de triage a l'utilisateur. Attendre validation.

**Phase 2 : ACTION (seulement sur ACTIF + PROTOTYPE approuves)**

Appliquer APEX Light sur chaque fichier ACTIF. Ne pas toucher aux DEAD.

**Phase 3 : CLEANUP (DEAD + PROTOTYPE refuses)**

En batch :
1. `cp fichier.go fichier.go.disabled` (backup)
2. Retirer de `build_secure_lia.sh`
3. Build gate
4. Commit unique pour tout le batch cleanup

**Avantage** : evite d'investir du temps a corriger du code que personne n'appelle.
RETEX 2026-03-18 : 14 fichiers audites, 10 etaient dead code. Sans triage, l'agent a corrige les 14 (stubs + renommages inutiles).

## Supervision adaptee au risque

| Risque | Supervision | Exemples |
|--------|-------------|----------|
| Faible | Autonome (`-a`) | UI cosmetic, typo, ajout champ |
| Moyen | Guidee | Nouveau composant, nouvelle route API |
| Eleve | Surveillee (`-x -t`) | Auth, securite, moteur, migrations DB |
| Critique | Full pipeline (`-x -t -pr`) | Compliance, donnees client, deploiement |
